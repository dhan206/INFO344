URL to AWS instance hosting website: http://ec2-52-35-212-220.us-west-2.compute.amazonaws.com/

URL to GitHub Repo with PHP source code: https://github.com/dhan206/INFO344/tree/master/assignment1 