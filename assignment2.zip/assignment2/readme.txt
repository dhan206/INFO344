﻿URL to Azure instance:		http://derekhanpa2.azurewebsites.net/
URL to GitHub Repo:		https://github.com/dhan206/INFO344/tree/master/assignment2
URL to WebService Source Code:	https://github.com/dhan206/INFO344/tree/master/assignment2/dhanINFO344PA2/dhanINFO344PA2