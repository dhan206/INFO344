﻿namespace dhanINFO344PA2
{
    public class Dictionary<T>
    {
    }
}